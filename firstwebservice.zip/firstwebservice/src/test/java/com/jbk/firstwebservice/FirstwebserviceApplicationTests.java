package com.jbk.firstwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
